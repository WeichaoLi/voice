//
//  UIPlaceHolderTextView.h
//  MSCDemo
//
//  Created by iflytek on 13-6-17.
//  Copyright (c) 2013年 iflytek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIPlaceHolderTextView : UITextView
@property (nonatomic, strong) NSString *placeholder;
@property (nonatomic, strong) UIColor *placeholderColor;
@property (nonatomic, strong) UILabel *placeHolderLabel;
-(void)textChanged:(NSNotification*)notification;
@end
