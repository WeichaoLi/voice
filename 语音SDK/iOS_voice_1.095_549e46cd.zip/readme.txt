------------------------------------
1.095版本信息 20141222
------------------------------------
1. 增加对armv7s的支持；
2. 修改识别类onEndOfSpeech回调有可能不返回的问题；
3. 修改语法识别时，不按停止键无法获取识别结果的现象；
4. 修改在UI听写界面时，进入到后台容易产生崩溃的现象；
5. 修改联系人上传时容易崩溃的问题；

------------------------------------
1.093版本信息
------------------------------------
1. 修改合成进度100时，音频文件没有保存完整的问题；
2. 修复UI听写界面启动时，切换到后台再进入，产生画面冻屏的现象；
3. 修改录音音量返回延迟的问题；
4. 修改UI听写界面录音音量波形与音量表示不一致的问题。

------------------------------------
1.091版本信息
------------------------------------
1. 修复8k采样率时，合成音频错误的问题
2. 修改听写音量相关问题
3. 修复合成音频文件末端缺少数据的bug

------------------------------------
1.088版本信息
------------------------------------
1. 修复Demo中上传的词表JSON字符串不正确的问题
2. 合成识别前增加AudioSession配置


------------------------------------
1.086版本信息
------------------------------------
1. 修复带UI界面旋转的问题；


------------------------------------
1.082版本信息
------------------------------------
20140922
1. 修复IFlyResourceUtil类被参与两次，导致在外部工程编译时，如果other link flags为_all_load时报重复定义；
2. 修复合成在锁屏状态时启动失败的问题。
------------------------------------

1.081版本信息
------------------------------------
1. 修复：频繁点击音频流识别，然后跳转到语法识别界面，会出现10132的问题

------------------------------------
1.080版本信息
------------------------------------
1. 继续修复音频流识别频繁调用导致的问题；
2. 修复底层msc的zip开源库与外部开发者编译冲突的问题；

------------------------------------
1.079版本信息
------------------------------------
1.1079增加了对arm64的支持
2.尝试修改音频流识别频繁调用导致服务不可用的问题。

------------------------------------

1.078版本信息
------------------------------------
1.078为带本地能力的版本，包含本地唤醒，本地语法识别，本地合成


------------------------------------
1.077版本信息
------------------------------------
1077为稳定版本，20140825日上线
内核采用mscv5 1071版本

修改bug：
1、修复手机连接wifi时，wifi没有访问互联网的能力，启动demo并等待一段时间后，会造成崩溃的问题；
2、修复带界面的听写，偶尔出现的没有回调的现象；
3、修复SDK内部的base64的全局变量命名，避免与外部第三方库共同造成编译错误。

------------------------------------
1.070版本信息
1、修复设置识别不返回标点参数无效问题
2、上传结构化日志

------------------------------------
1.068版本信息
组织相关的评审（接口，代码，新手指南),修改接口,使接口更容易使用。
修改接口包括：
1、识别回调接口IFlyRecognizerViewDelegate
原来：- (void)onResult:(IFlyRecognizerView *)iFlyRecognizerView theResult:(NSArray *)resultArray 
改为：- (void)onResult:(NSArray *)resultArray isLast:(BOOL) isLast;

原来：- (void)onEnd:(IFlyRecognizerView *)iFlyRecognizerView theError:(IFlySpeechError *) error;
改为：- (void)onError: (IFlySpeechError *) error;

2、识别接口 IFlySpeechRecognizer
原来：+ (id) createRecognizer:(NSString *)params delegate:(id<IFlySpeechRecognizerDelegate>) delegate
改为：+ (id) sharedInstance

原来：- (BOOL) setParameter:(NSString *) key value:(NSString *) value;
改为：- (BOOL) setParameter:(NSString *) value forKey:(NSString*)key;

增加：-(BOOL) isListening;
删除：+ (IFlySpeechRecognizer *) getRecognizer;

3、合成接口 IFlySpeechSynthesizer
原来：+ (IFlySpeechSynthesizer *) createWithParams:(NSString *) params delegate:(id<IFlySpeechSynthesizerDelegate>)delegate;
改为：+ (id) sharedInstance

原来：- (BOOL) setParameter:(NSString *) key value:(NSString *) value;
改为：- (BOOL) setParameter:(NSString *) value forKey:(NSString*)key;

增加：-(BOOL) isSpeaking;
删除：+ (IFlySpeechSynthesizer *) getSpeechSynthesizer;

4、登录接口
原来：
IFlySpeechUser
- (IFlySpeechError *) login:(NSString *) user pwd:(NSString *)pwd param:(NSString *) param;
改为：
IFlySpeechUtility
+ (IFlySpeechUtility*) createUtility:(NSString *) params;

登出
原来：-(void) logout;
改为：+(BOOL) destroy;

5、文本转语义接口 IFlyTextUnderstander
原来：-(NSString*) understandText:(NSString*) text Parameters:(NSString*) parameters Error:(IFlySpeechError **)error;
改为：-(int) understandText:(NSString*)text withCompletionHandler:(IFlyUnderstandTextCompletionHandler) completionHandler;

6、上传接口 IFlyDataUploader
原来：- (void) uploadData:(NSString *)name params:(NSString *) params data:(NSString *)data;
改为：- (void) uploadDataWithCompletionHandler:(IFlyUploadDataCompletionHandler)completionHandler name:(NSString *)name data:(NSString *)data;

7、新增常量定义类：IFlySpeechConstant
------------------------------------
1.066版本信息
1、增加文本转语义接口（输入文本内容，获取语义理解结果）
------------------------------------
1.065版本信息
1、增加语义理解和音频流识别接口；
2、更改登录接口synchronousLogin为login；
3、修复grammarId每次识别都有传入问题；
4、上传接口支持Block；
5、Demo的内存管理方式改为ARC；
6、Demo删除对adsupport库的依赖。

------------------------------------
1.063版本信息
1、修改MSC内部lua源码与外部lua源码编译冲突的问题；
2、去除对AdSupport.framework的依赖；
3、修复内存泄露；
4、支持arc；
5、修复蓝牙耳机连接问题。

------------------------------------
1.062版本信息
1、修改MSC内部lua源码与外部lua源码编译冲突的问题；
2、去除对AdSupport.framework的依赖。

------------------------------------
1.058版本信息
1、增加音频保存的功能
2、增加64位架构的支持
3、增加新的API文档和新手指南替换以前的开发指南

------------------------------------
1.047版本信息
1、修正了无UI版本目录下文档实际是有UI的错误
2、更换了文档的文件名，和现网文档一致


------------------------------------
1.046版本信息
1、在iOS7 sdk下重新编译了静态库和Demo，解决Xcode5和iOS7下语音服务不能用的情况
2、调整了iOS7下UI的显示
3、完善了语音后台播放

------------------------------------
1.043版本信息

1.修改
- (BOOL) startListening:(NSString *)params grammar:(NSString *)grammar;
函数没有返回值的语法错误；
2.将onBeginOfSpeech，onEndOfSpeech，。。。，onError等回调中
    [self performSelectorOnMainThread:@selector(end:) withObject:errorCode waitUntilDone:YES];
    修改为：
     [self performSelectorOnMainThread:@selector(end:) withObject:errorCode waitUntilDone:NO];

------------------------------------
1.042版本信息
1. 识别在快速切换时，界面不响应的bug。
2. 修改了识别时startListening函数的返回值。
------------------------------------

1.041版本

1. 修复了音频播放进度不准确的bug。
2. 对合成的流程进行了优化。
------------------------------------
1.038版本信息

1.集成1030版本msc
2.修改了上传命令词和语法的参数，仍然兼容以前的版本
------------------------------------
1.037版本信息

1.集成1029版本的msc
------------------------------------

1.036版本信息

1.修复tts播放进度异常
2.去掉IOKit.framework的支持
3.修复语音识别界面异常问题
4.优化语音识别的速度
------------------------------------

1.035版本信息

1.修复1034版本中无UIdemo的崩溃问题
2.修复oncancel回调异常的问题
------------------------------------
1.033版本信息

1.修复DebugLog的冲突问题
------------------------------------
1.032版本信息
1.修复了当传递的参数含有逗号时报10111的bug
2.修复了demo中崩溃的bug
------------------------------------
1.029版本信息

1.增加无UI的版本
2.优化语音识别的效率
3.修改语音识别和语音合成的demo，将abnf语法和asr的demo分开
4.增加是否打印msc.log和打印的等级的控制接口
5.添加联系人和个性化词条上传功能
-----------------------------------------
1.021版本信息


1.语音合成和识别支持蓝牙设备

2.解决个性发音人设置失败的bug

3.解决程序非背景模式下，合成锁屏造成的崩溃

4.getUpflow和getDownflow方法增加参数，TRUE表示获取识别或者合成某一项服务所有流量，FALSE表示单次会话的流量

-----------------------------------------

1.017版本信息



1.修改掉当服务器返回错误的参数时,客户端崩溃的现象

2.修改掉tts连续合成会有重音和不能启动播放器的bug

3.优化了录音启动时间和识别等待时间

4.修复了部分描述性文字并增加语音识别时的提示文字

-----------------------------------------

1.016版本信息



1.修改掉当服务器返回错误的参数时,客户端崩溃的现象

2.修改掉tts连续合成会有重音和不能启动播放器的bug

3.优化了录音启动时间和识别等待时间

-----------------------------------------

1.015版本更新信息

1.支持armv7s和armv7指令集
2.解决ios6下TTS语音播放不能达到100%的问题
3.更改了部分接口的命名
4.增加用户登录的接口
5.增加命令词上传功能
6.增加命令词识别功能
------------------------------------------
1.014版本更新信息

1.去掉getVersion接口
2.修改demo不能直接运行的问题
------------------------------------------
1.013版本更新信息

1.解决频繁调用TTS崩溃现象
2.解决合成完成时，点击重新合成按钮无反应的bug
3.解决在无网络的情况下，界面消失不正常的现象
4.将iFlyTTS.framework 和 iFlyISR.framework 合并为iFlyMSC.framework
5.此版本支持的指令集为：armv6、armv7
6.添加是否显示log的接口
------------------------------------------
1.012版本更新信息

1.识别有误时，增加“重新说话”按钮
------------------------------------------
1.011版本更新信息

1.修复了开发者在使用中提出的一些常见问题，同时在服务器端优化了网络服务，获取语音服务更顺畅准确
------------------------------------------
1.010版本更新信息

1.修改合成获取音频缓冲回调接口中包含全角符号的BUG
------------------------------------------
1.009版本更新信息

1.合成新增加获取音频缓冲和播放进度的回调接口
------------------------------------------
1.008版本更新信息

1.修改了ios5.0平台出现的BUG
2.并将json和reachability组件剥离
3.解决部分用户反馈的命名冲突问题


